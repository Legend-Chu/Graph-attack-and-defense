# Graph-attack-and-defense
Code for the paper Entropy-Based Node Removal for Robust Defense Against Graph Injection Attacks
